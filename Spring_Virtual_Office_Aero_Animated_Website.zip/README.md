# Spring Virtual Office Aero Animated Website

A public animated Aero Glass themed website for Spring Virtual Office.

## Included Pages

Home
AI Chat
Appointments
About
Admin Dashboard

## Theme

Windows Aero inspired glass design
Animated glowing background
Floating orbs
Blurred glass panels
Glossy buttons
Smooth hover effects
Page fade in animation

## Use

Open index.html in your browser.

If connected to the Spring Virtual Office FastAPI backend, the chat, appointment, and admin pages call:

/api/chat/
/api/appointments/
/api/alerts/
