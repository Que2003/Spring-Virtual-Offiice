async function sendMessage() {
    const name = document.getElementById("name")?.value || "Website Visitor";
    const contact = document.getElementById("contact")?.value || null;
    const message = document.getElementById("message")?.value || "";
    const chatBox = document.getElementById("chatBox");

    if (!message.trim()) {
        chatBox.innerHTML = '<div class="message bot">Spring Virtual Office: Please enter a message first.</div>';
        return;
    }

    chatBox.innerHTML = '<div class="message bot">Spring Virtual Office is thinking...</div>';

    try {
        const response = await fetch("/api/chat/", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({
                user_name: name,
                user_contact: contact,
                message: message,
                platform: "web"
            })
        });

        const data = await response.json();

        chatBox.innerHTML = `
            <div class="message user">You: ${escapeHtml(message)}</div>
            <div class="message bot">Spring Virtual Office: ${escapeHtml(data.response)}</div>
            ${data.needs_owner_alert ? '<div class="message bot">Owner alert created.</div>' : ''}
        `;
    } catch (error) {
        chatBox.innerHTML = '<div class="message bot">Backend is not connected yet. Connect this website to your Spring Virtual Office FastAPI server.</div>';
    }
}

async function requestAppointment() {
    const data = {
        name: document.getElementById("name")?.value || "",
        email: document.getElementById("email")?.value || null,
        phone: document.getElementById("phone")?.value || null,
        reason: document.getElementById("reason")?.value || "",
        preferred_day: document.getElementById("day")?.value || "",
        preferred_time: document.getElementById("time")?.value || "",
        contact_method: document.getElementById("contact_method")?.value || "",
        platform: "web"
    };

    const result = document.getElementById("result");

    if (!data.name || !data.reason || !data.preferred_day || !data.preferred_time || !data.contact_method) {
        result.innerText = "Please complete all required fields.";
        return;
    }

    try {
        const response = await fetch("/api/appointments/", {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(data)
        });

        const output = await response.json();
        result.innerText = output.message || "Appointment request submitted.";
    } catch (error) {
        result.innerText = "Backend is not connected yet. Connect this page to your Spring Virtual Office FastAPI server.";
    }
}

async function loadAdminData() {
    const appointmentsDiv = document.getElementById("appointments");
    const alertsDiv = document.getElementById("alerts");

    try {
        const appointmentResponse = await fetch("/api/appointments/");
        const appointmentData = await appointmentResponse.json();

        const alertResponse = await fetch("/api/alerts/");
        const alertData = await alertResponse.json();

        appointmentsDiv.innerHTML = "";
        alertsDiv.innerHTML = "";

        if (!appointmentData.appointments || appointmentData.appointments.length === 0) {
            appointmentsDiv.innerHTML = "<p>No appointments yet.</p>";
        }

        appointmentData.appointments?.forEach(item => {
            appointmentsDiv.innerHTML += `
                <div class="admin-card">
                    <strong>${escapeHtml(item.name)}</strong><br>
                    Reason: ${escapeHtml(item.reason)}<br>
                    Preferred: ${escapeHtml(item.preferred_day)} at ${escapeHtml(item.preferred_time)}<br>
                    Contact: ${escapeHtml(item.contact_method)}<br>
                    Email: ${escapeHtml(item.email || "N/A")}<br>
                    Phone: ${escapeHtml(item.phone || "N/A")}
                </div>
            `;
        });

        if (!alertData.alerts || alertData.alerts.length === 0) {
            alertsDiv.innerHTML = "<p>No alerts yet.</p>";
        }

        alertData.alerts?.forEach(item => {
            alertsDiv.innerHTML += `
                <div class="admin-card">
                    <strong>${escapeHtml(item.priority.toUpperCase())} ALERT</strong><br>
                    User: ${escapeHtml(item.user_name)}<br>
                    Contact: ${escapeHtml(item.user_contact || "N/A")}<br>
                    Reason: ${escapeHtml(item.reason)}<br>
                    Message: ${escapeHtml(item.message)}<br>
                    Platform: ${escapeHtml(item.platform)}
                </div>
            `;
        });
    } catch (error) {
        appointmentsDiv.innerHTML = "<p>Backend is not connected yet.</p>";
        alertsDiv.innerHTML = "<p>Backend is not connected yet.</p>";
    }
}

function escapeHtml(text) {
    return String(text)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}
